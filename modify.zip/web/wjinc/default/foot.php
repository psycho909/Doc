<style>
	.ui-widget{
		top:200px !important;
	}
	#ykdl{
		display:none;
	}
</style>

<div class="footer p-3">
	<div class="container">
		<div class="row mb-2">
			<div class="col-12 text-center">
				<img src="/skin/images/foot2.jpg" alt="" class="img-fluid">
			</div>
		</div>
		<div class="row service-row mb-2">
			<div class="col">
				<div class="d-flex justify-content-center">
					<a href="javascript:;" class="px-2 text-white">关于我们</a>
					<a href="javascript:;" class="px-2 text-white">联系我们</a>
					<a href="javascript:;" class="px-2 text-white">代理合作</a>
					<a href="javascript:;" class="px-2 text-white">存款帮助</a>
					<a href="javascript:;" class="px-2 text-white">提款帮助</a>
					<a href="javascript:;" class="px-2 text-white">常见问题</a>
					<a href="javascript:;" class="px-2 text-white">产品优势</a>
					<a href="javascript:;" class="px-2 text-white">更多服务</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col text-center">
				<span class="copyright">COPYRIGHT © CASINO RESERVED</span>
			</div>
		</div>
	</div>
</div>
  <!--div class="left_adv">
    <a href="http://www.wangzhi.com/" target="_blank"><img src="/jh/images/MQ2.png"></a>
  </div>

<div class="socialnavi">
	<div class="wechatqr">
		<img src="/dsn/wechat_qr1.png" alt="">
	</div>
	<div class="downloadqr" style="display: none;"><p>下载网址<br>
防劫持发布器</p></div>
<?php 
				 $sql="select * from ssc_params" ;
				 $data = $this->getRows($sql);
					?>
	<div class="qq" onclick="javascript:window.open('<?=$this->qq?>','_blank')"></div>
	<div class="wechat" onclick=""></div>
	<div class="livechat" onclick="javascript:window.open('<?=$this->qq?>','_blank')"></div>
	<div class="download" onclick="javascript:window.open('http://www.fuda8.com/','_blank')"></div>
	<div>
		<a href="javascript:;" onclick="scrolltop();" class="scrolltop" style="display: none;"><img src="/jh/images/support_top.png" width="50" height="50" alt=""></a>
	</div>

</div-->



<div id="ykdl" class="ui-dialog ui-widget ui-widget-content ui-corner-all dialog ui-draggable ui-dialog-buttons" tabindex="-1" role="dialog" aria-labelledby="ui-id-1" style="outline: 0px; z-index: 1002; height: auto; width: 360px; top: 200px; left: 772px;">
	<div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix">
		<span id="ui-id-1" class="ui-dialog-title">消息</span>
		<a href="#" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span class="ui-icon ui-icon-closethick" onclick="close1()">close</span></a>
	</div>
	<div id="dialog" class="ui-dialog-content ui-widget-content" scrolltop="0" scrollleft="0" style="display: block; width: auto; min-height: 81px; height: auto;">
		<div class="field-c">
			<div class="icon"></div>
			<div class="msg">
				<p>您还没有登录！</p>
			</div>
		</div>
	</div>
	<div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix">
		<div class="ui-dialog-buttonset">
			<a href="javascript:guestLogin();"><button class="btn btn-blue">游客登录</button></a>
		</div>
	</div>
</div>

<script src="/jh/js/jquery.bxslider.min.js"></script>
<script src="/jh/js/plugins.js"></script>
<script src="/jh/js/main.js"></script>    
<script>
	function ykdl(){
		$("#ykdl").show();
	}
	function close1(){
		$("#ykdl").hide();
	}
</script>
</body></html>