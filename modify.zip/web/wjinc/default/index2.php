<?php $this->display('head.php');?>
    <div class="main-wrap">
        <!-- Carousel區 -->
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="/skin/images/carousel01.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="/skin/images/carousel02.jpg" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="/skin/images/carousel03.jpg" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <!-- /Carousel區 -->
        <div class="container-fluid my-3">
            <div class="row justify-content-center">
                <div class="col-10">
                    <div class="row bn-row">
                        <div class="col bn-col">
                            <a href="javascript:;">
                                <img class="img-fluid" src="/skin/images/bn01.jpg" alt="" data-img="/skin/images/bn01-hover.jpg">
                            </a>
                        </div>
                        <div class="col bn-col">
                            <a href="javascript:;">
                                <img class="img-fluid" src="/skin/images/bn02.jpg" alt="" data-img="/skin/images/bn02-hover.jpg">
                            </a>
                        </div>
                        <div class="col bn-col">
                            <a href="javascript:;">
                                <img class="img-fluid" src="/skin/images/bn03.jpg" alt="" data-img="/skin/images/bn03-hover.jpg">
                            </a>
                        </div>
                        <div class="col bn-col">
                            <a href="javascript:;">
                                <img class="img-fluid" src="/skin/images/bn04.jpg" alt="" data-img="/skin/images/bn04-hover.jpg">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- mask -->
<div class="back_body" style="display:none;" onclick="$('#popup_video').children('iframe').attr('src', $('#popup_video').children('iframe').attr('src'));$('#popup_video, .back_body').hide();"></div>
<!-- /mask -->

<script>
if($("#ticker2").is('.con_ts1')){
    var a =["qq","132","we","ka","adw","qewq","134","az","ds","qew","szd","139","jhg","yrr","vbn","135","sd","qiu","hut","vbf","138","mjh","jkmh","jh","kf","iuq","158","poq","hvn","bv","fas","ddd","gosd","baood","baeo","ba44","1558","a77765","bafd","1333","1785","nabo","bao","mio","zuiren","yelong","dingshe","liang","aod","k3224","23kk","goad","8966"];
    var i ;
    function showTest(){
        
        for( i =0 ; i<53 ;i++){
            var b ="";
            var k = Math.ceil(Math.random()*38);
            var j = Math.ceil(Math.random()*100000);
            b += a[k];
            c = "<li><a href=''>恭喜会员 "+b+"*** 提款 "+(j)+" 元成功,请及时查看帐目。</a></li>";
            $(".con_ts1").append(c);
        }

    }

    showTest();
}
</script>

<?php $this->display('foot.php');?>