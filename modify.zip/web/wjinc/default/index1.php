<!DOCTYPE html>
<html>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
<title><?= $this->iff($args[0], $args[0] . '－') . $this->settings['webName'] ?></title>
<meta name="renderer" content="webkit"/>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
<meta name="keywords" content=""/>
<meta name="description" content=""/>
<script type="text/javascript">
    /* var baseUrl = "http://"+window.location.host+"/"; */
    var url = '/api/checkLoginJs.do?t=' + Math.random();
    document.write("<script type='text/javascript' src='" + url + "'><\/script>");
    document.close();
</script>

<!-- css -->
<!-- <link href="static/css/index.pack.min.css?v=1610251708" rel="stylesheet"/> -->
<link rel="stylesheet" type="text/css" href="../../skin/17/new_index1.css"/>
<link rel="stylesheet" href="../../skin/css/bootstrap.min.css">
<link rel="stylesheet" href="../../skin/css/bootstrap-grid.css">
<link rel="stylesheet" href="../../skin/css/custom_index1.css">

<script type="text/javascript" src="/static/lib/jquery/jquery-1.11.2.min.js"></script>

<script type="text/javascript" src="/static/lib/layer/layer.js"></script>
<script type="text/javascript" src='/config/config.js'></script>

<!-- js -->
<script type="text/javascript" src="/static/js/index.pack.min.js?v=1610251708"></script>

<script type="text/javascript" src="/static/data/gamedatas.js"></script>
<script type="text/javascript" src="../../skin/js/custom_index1.js"></script>
<script type="text/javascript">
    var staticFileUrl = getStaticDomain();
    HttpUtil.loadJs(staticFileUrl + "data/dataVersion.js?t=" + Math.random());
</script>

<script type="text/javascript">
    $("html").hide();
    layer.config({
        skin: 'demo-class'
    });

    $.ajaxSetup({
        cache: false //close AJAX cache
    });

    $LAB
        .script("/api/getServerData.do?t=" + Math.random())
        .script('/game/getServerData.do?t=' + Math.random())
        .script(staticFileUrl + 'data/messages.js?v=' + dataVersion)
        .script(staticFileUrl + 'data/paramcfg.js?v=' + dataVersion)
//      .script(staticFileUrl + 'data/gamedatas.js?v=' + dataVersion)
        .script(staticFileUrl + 'data/configjs.js?v=' + dataVersion)
        .script(staticFileUrl + 'data/gameCommon.js')
        //.script(staticFileUrl + 'data/playCates.js')
        //.script(staticFileUrl + 'data/plays.js')
        .wait(function () {// 等待所有script加载完再执行这个代码块
            $("html").show();
            //处理声音
            SoundManage.initVoiceSwitch();
            //处理子页面
            //frameAutoHeight();

            // 自定义
            //iframeAutoHeight()
            //window.setInterval(iframeAutoHeight, 200);
            //处理游戏菜单
            HomeMenu.init();
            //判断用户账号是否已封停
            if (user.enable == 0) {//账号封停
                layer.open({
                    title: "提示",
                    type: 1,
                    area: ['250px', '120px'],
                    closeBtn: 0,
                    shift: 2,
                    shadeClose: false,
                    content: "<div style='margin: 10px;'>您的账号已经被冻结，请联系上级！</div>"
                });
            }

            if (user.updatePw == 1) {//是否需要修改密码
                UserInfos.showUpdatePwWin();
            }


            // 同步时间
            SyncSysDate.sync();

            // 隐藏游客权限
            trialGameProPageInit();

            // 处理是否需要显示默认的隐藏按钮
            showSysBtn();

            HomeMenu.showInfo();

            // 每10秒请求一次消息
            window.setInterval(function () {
                PullMsg.getUserMsg(200);
            }, 10000);

            $('a[target="framePage"]').bind('click', function (event) {
                $("#framePage").attr("src", $(this).attr('href'));
                event.preventDefault();
                event.stopPropagation();
            });

//		PullMsg.getLotteryData();

            //事件
            document.onkeydown = function (e) {
                var theEvent = window.event || e;
                var code = theEvent.keyCode || theEvent.which;
                if (code == 13) {
                    if (UserBet.step == 0) {
                        UserBet.openBetWindow();
                    } else if (UserBet.step == 1) {
                        UserBet.submitBet();
                        if (UserBet.step == 0) {
                            setTimeout(function () {
                                layer.closeAll();
                            }, 200);
                        }
                    }
                }
            }

            //公告
            var noticeList = MESSAGES.type_1; //公告列表
            if (noticeList) {
                var html = "<ul>";
                $.each(noticeList, function (index, item) {
                    html += '<li><a href="javascript:showAnnounceList()">' + item.title + '</a></li>'
                });
                html += "</ul>";

                $('#announce-list').html(html);
            }
            $('#announce-list').scrollbox({
                speed: 100
            });
        })
    ;

    function showAnnounceList() {
        layer.open({
            type: 2,
            title: '公告列表',
            shadeClose: true,
            scrollbar: false,
            shade: [0.5],
            area: ['700px', '400px'],
            content: '/notice/list.html?t=' + Date.parse(new Date())
        });
    }

    $(function () {
        $(".more_game").mouseover(function () {
            $(".popPanel").show();
        }).mouseout(function () {
            setTimeout(
                function () {
                    $(".popPanel").hide();
                }, 4300);
        });
    });

</script>
</head>
<body>
    <!-- 總體 -->
    <div class="main-body">
        <div class="header container-fluid mb-5">

            <!-- logo區 -->
            <div class="row justify-content-xl-end pt-5 pb-4">
                <div class="col-xl-4 col-4 d-flex justify-content-center align-items-center">
                    <div class="logo2" style="text-align: center;">
                        <!--<img src='' alt="<?= $this->iff($args[0], $args[0] . '－') . $this->settings['webName'] ?>" height="53"
                            id="domain_logo_url">-->
                            <img src="../../skin/images/logo.png"/ height="48px" class="img-fluid logo">
                        <script type="text/javascript">
                            //处理默认样式
                            // changePageSkin();
                        </script>
                    </div>
                </div>
                <div class="col-xl-4 col-6 ml-xl-0 ml-auto">
                    <div class="d-flex flex-column pr-xxl-5">
                        <div class="d-flex mb-2">
                            <div class="title mr-1">
                                <a class="top-btn convert" href="javascript:;" target="framePage">額度轉換</a>
                            </div>
                            <div class="title mr-1">
                                <a class="top-btn deposit" href="/center/pay/index.html?v6" target="framePage">線上存款</a>
                            </div>
                            <div class="title mr-1">
                                <a class="top-btn withdraw" href="/center/withdraw/index.html" target="framePage">線上提款</a>
                            </div>
                            <div class="title mr-1">
                                <a class="top-btn history" href="/center/pay/list.html" target="framePage">存款紀錄</a>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between">
                            <div class="info d-flex align-items-center">
                                <label class="mb-0 username">账号:</label>
                                <span id="userinfo_name">加载中</span>
                                <script type="text/javascript">
                                    $("#userinfo_name").html(user.userName);
                                </script>
                            </div>
                            <div class="info d-flex align-items-center">
                                <label class="mb-0 balance">帐号余额:</label>
                                <span id="userinfo_money" class="balance">加载中</span>
                            </div>
                            <div class="info d-flex align-items-center">
                                <label class="mb-0 text-white">未结金额:</label>
                                <span id="userinfo_unbalancedMoney" class="betting">加载中</span>
                                <a href="javascript:PullMsg.getLotteryData(200)" title="点击刷新消息">
                                    <img alt="点击刷新消息" src="/static/images/refresh.png" width="18" height="18" title="点击刷新消息" style="vertical-align: middle;cursor:pointer">
                                </a>
                            </div>
                            <a href="javascript:logout();" class="top-btn logout m-0">登出</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /logo區 -->
            <div class="row justify-content-center">
                <div class="col-xl-11 col-lg-12 col-12">
                    <div class="row menu-row">
                        <div class="col-99 text-center"><a href="/">首页</a></div>
                        <div class="col-99 text-center"><a href="At6.php">优惠信息</a></div>
                        <div class="col-99 text-center"><a href="javascript:;">彩票游戏</a></div>
                        <div class="col-99 text-center"><a href="javascript:;">六合彩</a></div>
                        <div class="col-99 text-center"><a href="javascript:;">真人娱乐</a></div>
                        <div class="col-99 text-center"><a href="javascript:;">电子娱乐</a></div>
                        <div class="col-99 text-center"><a href="javascript:;">沙巴体育</a></div>
                        <div class="col-99 text-center"><a href="mobile.php">手机投注</a></div>
                        <div class="col-99 text-center"><a href="<?=$this->qq?>">代理加盟</a></div>
                    </div>
                </div>
            </div>

        </div>

        <!-- main -->
        <div class="main clearfix container-fluid">
            <div class="row">
                <!-- 遊戲選單 -->
                <div class="col-1515 p-0">
                    <div class="lotterys p-3 h-100">
                        <div class="today-record mb-3">
                            <div>今日输赢: <span class="today-record-num">0</span></div>
                        </div>

                        <!-- 遊戲選單menu -->
                        <div class="show d-flex flex-column" id="homeMenus"></div>
                        <!-- 遊戲選單 更多遊戲區下拉區 -->
                        <!-- /遊戲選單 更多遊戲區下拉區 -->
                        <a class="more_games" style="display: block;"><span>更多游戏 <b class="more_games_arrow">▼</b></span></a>
                        <!-- /遊戲選單menu -->
                        <div class="popPanel flex-column">
                            <a href="javascript:void(0)" id="l_TJSSC" lang="SSC_0"><span>天津时时彩</span></a>
                        </div>
                        
                    </div>
                </div>
                <!-- /遊戲選單 -->

                <!-- 遊戲主體 content -->
                <div class="content col pr-0">
                    <!-- 開獎 遊戲/期數 -->
                    <div class="draw_number d-none">
                        <div id="header_game_name"></div>
                        <div><span class="cur_turn_num" id="cur_turn_num"></span>期开奖</div>
                    </div>
                    <!-- /開獎 遊戲/期數 -->
                    <a id="result_balls" target="_blank" class="d-none"></a>
                    <!-- 遊戲玩法選單 -->
                    <div class="sub d-none" id="homeCateMenus">
                        <!-- 北京賽車(PK10) -->
                        <div id="cate_menus_50" class="show cate_menu">
                            <a class="selected" href="/game/pk10/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                                target="framePage" cate_id="1">两面盘</a>
                            |
                            <a href="/game/pk10/sol.html" target="framePage" onclick="HomeMenu.selCateMenuClass(this);" cate_id="2">单号1~10</a>
                            |
                            <a href="/game/pk10/com.html" target="framePage" onclick="HomeMenu.selCateMenuClass(this);" cate_id="3">冠亚组合</a>
                        </div>
                        <!-- /北京賽車(PK10) -->
                        <!-- 極速賽車 -->
                        <div id="cate_menus_72" class="show cate_menu">
                            <a class="selected" href="/game/jspk10/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                                target="framePage" cate_id="1">两面盘</a>
                            |
                            <a href="/game/jspk10/sol.html" target="framePage" onclick="HomeMenu.selCateMenuClass(this);"
                                cate_id="2">单号1~10</a>
                            |
                            <a href="/game/jspk10/com.html" target="framePage" onclick="HomeMenu.selCateMenuClass(this);"
                                cate_id="3">冠亚组合</a>
                        </div>
                        <!-- /極速賽車 -->
                        <!-- 幸運飛艇 -->
                        <div id="cate_menus_55" class="show cate_menu">
                            <a class="selected" href="/game/xyft/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                                target="framePage" cate_id="1">两面盘</a>
                            |
                            <a href="/game/xyft/sol.html" target="framePage" onclick="HomeMenu.selCateMenuClass(this);" cate_id="2">单号1~10</a>
                            |
                            <a href="/game/xyft/com.html" target="framePage" onclick="HomeMenu.selCateMenuClass(this);" cate_id="3">冠亚组合</a>
                        </div>
                        <!-- /幸運飛艇 -->
                        <!-- 重慶時時彩 -->
                        <div id="cate_menus_1" class="hide cate_menu">
                            <a class="selected" href="/game/cqssc/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">整合</a>
                            |
                            <a href="/game/cqssc/sol.html?ball=1" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="2">第一球</a>
                            |
                            <a href="/game/cqssc/sol.html?ball=2" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="3">第二球</a>
                            |
                            <a href="/game/cqssc/sol.html?ball=3" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="4">第三球</a>
                            |
                            <a href="/game/cqssc/sol.html?ball=4" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="5">第四球</a>
                            |
                            <a href="/game/cqssc/sol.html?ball=5" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="6">第五球</a>
                        </div>
                        <!-- /重慶時時彩 -->
                        <!-- 極速時時彩 -->
                        <div id="cate_menus_73" class="hide cate_menu">
                            <a class="selected" href="/game/jsssc/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">整合</a>
                            |
                            <a href="/game/jsssc/sol.html?ball=1" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="2">第一球</a>
                            |
                            <a href="/game/jsssc/sol.html?ball=2" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="3">第二球</a>
                            |
                            <a href="/game/jsssc/sol.html?ball=3" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="4">第三球</a>
                            |
                            <a href="/game/jsssc/sol.html?ball=4" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="5">第四球</a>
                            |
                            <a href="/game/jsssc/sol.html?ball=5" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="6">第五球</a>
                        </div>
                        <!-- /極速時時彩 -->
                        <!-- 廣東快樂十分 -->
                        <div id="cate_menus_60" class="hide cate_menu">
                            <a class="selected" href="/game/gdkl10/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">两面盘</a>
                            |
                            <a href="/game/gdkl10/sol.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="2">单号1~8</a>
                            |
                            <a href="/game/gdkl10/q1.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="3">第一球</a>
                            |
                            <a href="/game/gdkl10/q2.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="4">第二球</a>
                            |
                            <a href="/game/gdkl10/q3.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="5">第三球</a>
                            |
                            <a href="/game/gdkl10/q4.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="6">第四球</a>
                            |
                            <a href="/game/gdkl10/q5.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="7">第五球</a>
                            |
                            <a href="/game/gdkl10/q6.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="8">第六球</a>
                            |
                            <a href="/game/gdkl10/q7.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="9">第七球</a>
                            |
                            <a href="/game/gdkl10/q8.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="10">第八球</a>
                            |
                            <a href="/game/gdkl10/zm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="11">正码</a>
                            |
                            <a href="/game/gdkl10/lm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="12">连码</a>
                        </div>
                        <!-- /廣東快樂十分 -->
                        <!-- 江蘇骰寶 -->
                        <div id="cate_menus_10" class="hide cate_menu">
                            <a class="selected" href="/game/jsk3/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">大小骰宝</a>
                        </div>
                        <!-- /江蘇骰寶 -->
                        <!-- 幸運快3 -->
                        <div id="cate_menus_75" class="hide cate_menu">
                            <a class="selected" href="/game/xyk3/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">大小骰宝</a>
                        </div>
                        <!-- /幸運快3 -->
                        <!-- 吉林快三 -->
                        <div id="cate_menus_11" class="hide cate_menu">
                            <a class="selected" href="/game/jlk3/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">大小骰宝</a>
                        </div>
                        <!-- /吉林快三 -->
                        <!-- 廣西快三 -->
                        <div id="cate_menus_12" class="hide cate_menu">
                            <a class="selected" href="/game/gxk3/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">大小骰宝</a>
                        </div>
                        <!-- /廣西快三 -->
                        <!-- 湖北快三 -->
                        <div id="cate_menus_13" class="hide cate_menu">
                            <a class="selected" href="/game/hbk3/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">大小骰宝</a>
                        </div>
                        <!-- /湖北快三 -->
                        <!-- 內蒙古快3 -->
                        <div id="cate_menus_14" class="hide cate_menu">
                            <a class="selected" href="/game/nmgk3/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">大小骰宝</a>
                        </div>
                        <!-- /內蒙古快3 -->
                        <!-- 重庆幸运农场  -->
                        <div id="cate_menus_61" class="hide cate_menu">
                            <a class="selected" href="/game/xync/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">两面盘</a>
                            |
                            <a href="/game/xync/sol.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="2">单号1~8</a>
                            |
                            <a href="/game/xync/q1.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="3">第一球</a>
                            |
                            <a href="/game/xync/q2.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="4">第二球</a>
                            |
                            <a href="/game/xync/q3.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="5">第三球</a>
                            |
                            <a href="/game/xync/q4.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="6">第四球</a>
                            |
                            <a href="/game/xync/q5.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="7">第五球</a>
                            |
                            <a href="/game/xync/q6.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="8">第六球</a>
                            |
                            <a href="/game/xync/q7.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="9">第七球</a>
                            |
                            <a href="/game/xync/q8.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="10">第八球</a>
                            |
                            <a href="/game/xync/zm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="11">正码</a>
                            |
                            <a href="/game/xync/lm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="12">连码</a>
                        </div>
                        <!-- /重庆幸运农场  -->
                        <!-- 無 -->
                        <div id="cate_menus_65" class="hide cate_menu">
                            <a class="selected" href="/game/bjkl8/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">111总和、比数、五行</a>
                            |
                            <a href="/game/bjkl8/sol.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="2">正码</a>
                        </div>

                        <!-- 無 -->
                        <div id="cate_menus_66" class="hide cate_menu">
                            <a class="selected" href="/game/pcdd/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">PC蛋蛋</a>
                        </div>

                        <!-- 廣東11選5 -->
                        <div id="cate_menus_21" class="hide cate_menu">
                            <a class="selected" href="/game/gd11x5/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="1">两面</a>
                            |
                            <a href="/game/gd11x5/sol.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="1">单号</a>
                            |
                            <a href="/game/gd11x5/lm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="1">连码</a>
                            |
                            <a href="/game/gd11x5/zx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="1">直选</a>
                        </div>
                        <!-- /廣東11選5 -->
                        <!-- 香港六合彩 -->
                        <div id="cate_menus_70" class="hide cate_menu">
                            <a class="selected" href="/game/lhc/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="85">特码</a>
                            |
                            <a href="/game/lhc/2m.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="86">两面</a>
                            |
                            <a href="/game/lhc/sb.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="87">色波</a>
                            |
                            <a href="/game/lhc/tx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="88">特肖</a>
                            |
                            <a href="/game/lhc/hx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="89">合肖</a>
                            |
                            <a href="/game/lhc/tws.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="90">特码头尾数</a>
                            |
                            <a href="/game/lhc/zm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="91">正码</a>
                            |
                            <a href="/game/lhc/zmt.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="92">正码特</a>
                            |
                            <a href="/game/lhc/zm16.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="93">正码1~6</a>
                            |
                            <a href="/game/lhc/wx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="94">五行</a>
                            |
                            <a href="/game/lhc/ptyxws.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="95">平特一肖尾数</a>
                            |
                            <a href="/game/lhc/zx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="95">正肖</a>
                            |
                            <a href="/game/lhc/7sb.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="96">7色波</a>
                            |
                            <a href="/game/lhc/zhongxiao.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="97">总肖</a>
                            |
                            <a href="/game/lhc/zxbz.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="98">自选不中</a>
                            |
                            <a href="/game/lhc/lxlw.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="99">连肖连尾</a>
                            |
                            <a href="/game/lhc/lm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="100">连码</a>
                        </div>
                        <!-- /香港六合彩 -->
                        <!-- 極速六合彩 -->
                        <div id="cate_menus_74" class="hide cate_menu">
                            <a class="selected" href="/game/lhc/index.html" onclick="HomeMenu.selCateMenuClass(this);"
                            target="framePage" cate_id="85">特码</a>
                            |
                            <a href="/game/lhc/2m.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="86">两面</a>
                            |
                            <a href="/game/lhc/sb.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="87">色波</a>
                            |
                            <a href="/game/lhc/tx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="88">特肖</a>
                            |
                            <a href="/game/lhc/hx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="89">合肖</a>
                            |
                            <a href="/game/lhc/tws.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="90">特码头尾数</a>
                            |
                            <a href="/game/lhc/zm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="91">正码</a>
                            |
                            <a href="/game/lhc/zmt.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="92">正码特</a>
                            |
                            <a href="/game/lhc/zm16.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="93">正码1~6</a>
                            |
                            <a href="/game/lhc/wx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="94">五行</a>
                            |
                            <a href="/game/lhc/ptyxws.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="95">平特一肖尾数</a>
                            |
                            <a href="/game/lhc/zx.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="95">正肖</a>
                            |
                            <a href="/game/lhc/7sb.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="96">7色波</a>
                            |
                            <a href="/game/lhc/zhongxiao.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="97">总肖</a>
                            |
                            <a href="/game/lhc/zxbz.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="98">自选不中</a>
                            |
                            <a href="/game/lhc/lxlw.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage"
                            cate_id="99">连肖连尾</a>
                            |
                            <a href="/game/lhc/lm.html" onclick="HomeMenu.selCateMenuClass(this);" target="framePage" cate_id="100">连码</a>
                        </div>
                        <!-- /極速六合彩 -->

                    </div>
                    <!-- /遊戲玩法選單 -->
                    <iframe id="framePage" name="framePage" src="" width="100%" height="600px"
                            style="border: none;bacbackground-color: #feefef" allowTransparency="true" border="0"
                            frameborder="no"
                            onload="iFrameAutoHeight()"></iframe>
                </div>
                <!--/遊戲主體 content-->
            </div>
        </div>
        <!--/main-->

        <!--announce-box-->
        <audio src="/static/sound/du.mp3" id="duSound" style="display:none;"></audio>
        <audio src="/static/sound/win.mp3" id="winSound" style="display:none;"></audio>
        <audio src="/static/sound/new_msg.mp3" id="nweNoticeSound" style="display:none;"></audio>
        
    </div>
    <!-- /總體 -->
    <div class="footer p-3">
        <div class="container">
            <div class="row mb-2">
                <div class="col-12 text-center">
                    <img src="/skin/images/foot2.jpg" alt="" class="img-fluid">
                </div>
            </div>
            <div class="row service-row mb-2">
                <div class="col">
                    <div class="d-flex justify-content-center">
                        <a href="javascript:;" class="px-2 text-white">关于我们</a>
                        <a href="javascript:;" class="px-2 text-white">联系我们</a>
                        <a href="javascript:;" class="px-2 text-white">代理合作</a>
                        <a href="javascript:;" class="px-2 text-white">存款帮助</a>
                        <a href="javascript:;" class="px-2 text-white">提款帮助</a>
                        <a href="javascript:;" class="px-2 text-white">常见问题</a>
                        <a href="javascript:;" class="px-2 text-white">产品优势</a>
                        <a href="javascript:;" class="px-2 text-white">更多服务</a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                    <span class="copyright">COPYRIGHT © CASINO RESERVED</span>
                </div>
            </div>
        </div>
    </div>
    <!-- 下注明細 -->
    <div id="win_bet" class="hide" style="width: 430px; margin: 10px;">
        <div style="max-height: 280px; overflow-y:auto; margin-bottom: 10px">
            <table class="u-table10">
                <thead>
                <tr>
                    <th style="width: 60%;">号码</th>
                    <th style="width: 15%">赔率</th>
                    <th style="width: 15%">金额</th>
                    <th style="width: 10%">确认</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        <div class="bet-bottom"><span class="bcount">组数：<b class="bcountVal">0</b></span><span class="btotal">总金额：<b
                        class="btotalVal">0</b></span></div>
    </div>
    <!-- /下注明細 -->

    <!-- 右下角弹窗 -->
    <div id="user_msg_list" class="pop-tips hide">
        <h3 class="pop-tips-hd" id="user_msg_title"></h3>
        <div class="pop-tips-bd" id="user_msg_dev">
            <ul id="user_msg_content" class="mb10">
            </ul>
        </div>
        <a href="javascript:UserBet.closeUserMsgWiondow()" class="btn-pop-close">&times;</a>
    </div>
    <!--/右下角弹窗-->

    <!-- mask -->
    <div class="mask" id="mask"></div>
    <!-- /mask -->
    <script>
    $(window).resize(function(){
        var iframeHeight=$('#framePage').contents().find('.main').height()
        $('#framePage').height(iframeHeight+24)
        //$('.lotterys').height(iframeHeight)
    })
    function iFrameAutoHeight(){
        $('#framePage').load(function(){
            var $iframe=$(this).contents();
            var iframeHeight=$iframe.find('.main').height();
            
            // iframe高度控制
            $(this).height(iframeHeight+30)
            // 高度限制
            var mainHeight=$iframe.find('.main').outerHeight();
            $iframe.find('.stat_play_list').css({
                'display':'block',
                'max-height':mainHeight-50-48+'px'
            })
            // 替iframe增加CSS
            $iframe.find('.main').addClass('row')
            $iframe.find('.main .content').addClass('col')
            $iframe.find('.main .content .sub-wrap').addClass('row')
            $iframe.find('.main .content .sub-wrap .cont-main').addClass('col')
            $iframe.find('.main .content .sub-wrap .cont-main').addClass('col')
            $iframe.find('#stat_play_list').addClass('stat_play_list')

            // 遊戲名稱抓取
            $iframe.find('.header_game_name').text($('#header_game_name').text());
            
        })
    }
    </script>
</body>

</html>
