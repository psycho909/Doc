<?php if($this->user['uid']){	
	header('location: /');
	exit;
} ?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<link rel="icon" type="image/x-icon" href="images/favicon.ico">
<title>富达彩票-极速彩联盟</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/skin/css/bootstrap.min.css">
<link rel="stylesheet" href="/jh/css/jquery-ui.css">

<link rel="stylesheet" href="/jh/css/stylesheet.css">
<link rel="stylesheet" href="/jh/css/main.css">
<!-- <link rel="stylesheet" href="/jh/css/style.css"> -->
<!-- <link rel="stylesheet" href="/jh/css/index.css"> -->
<link rel="stylesheet" href="/jh/css/jquery.bxslider.css">
<link rel="stylesheet" href="/jh/css/notice_popup.css">
<link rel="stylesheet" href="/skin/css/custom_index2.css">

<!-- <script async="" src="/jh/js/analytics.js"></script> -->
<script src="/jh/js/jquery.1.9.min.js"></script>
<script src="/skin/js/popper.min.js"></script>
<script src="/skin/js/bootstrap.min.js"></script>

<script type="text/javascript" src="/jh/js/jquery-ui.js"></script>
<script type="text/javascript" src="/jh/js/dialog.js"></script>
<script type="text/javascript" src="/jh/js/libs.js"></script>
<script type="text/javascript" src="/jh/js/login.js"></script>

<script type="text/javascript" src="/jh/js/common.js"></script>	

<script type="text/javascript" src="/skin/main/reglogin.js"></script>	
<script type="text/javascript" src="/js/guest.js"></script>	
	
<script type="text/javascript" src="/jh/js/index.js"></script>
<script src="/skin/js/custom_index1.js"></script>
<script>
	var stat1 = 25;
	var statprogress1 = 25;  // 25%, percentage
	var stat2 = 120;
	var statprogress2 = 65;  // 65%, e
	var stat3 = 34;
	var affType = 0;
</script>
<script>
//   (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
//   (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
//   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
//   })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

//   ga('create', 'UA-93117741-1', 'auto');
//   ga('send', 'pageview');

</script>
</head>
<body id="bodyid" class="d-flex flex-column">
	<!-- top會員登入 -->
	<div class="top container-fluid mb-5">
		<div class="row justify-content-end pt-5 pb-4">
			<div class="col-4 d-flex justify-content-center align-items-center">
				<div class="logo2" style="text-align: center;">
					<img src="/skin/images/logo.png" class="img-fluid logo">
				</div>
			</div>
			<div class="col-4">
				<form action="/user/loginon" method="post">
					<div class="d-flex pr-5 mb-2">
						<div class="title">
							<a class="top-btn free-play" href="javascript:guestLogin();">免費試玩</a>
						</div>
						<div class="title ml-2">
							<a class="top-btn register" href="reg.php" target="framePage">立即開戶</a>
						</div>
						<div class="title ml-2">
							<a class="top-btn serivce" target="_blank" href="<?=$this->qq?>" target="framePage">在線客服</a>
						</div>
					</div>
					<div class="form-row pr-5">
						<div class="col-xxl-3 col"><input type="text" placeholder="会员账号" name="username" class="u-input uname form-control" id="userName1" maxlength="15" tabindex="1"></div>
						<div class="col-xxl-3 col"><input type="password" placeholder="密码" name="password" class="u-input upwd form-control" id="password1" maxlength="15" tabindex="2"></div>
						<a href="<?=$this->qq?> "target="_blank" class="btn-forget u-btn">忘记?</a>
						<button type="submit" class="btn btn-login u-btn ml-2" onclick="return check(form)">登陆</button>
					</div>
				</form>
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-xl-11 col-lg-12 col-12">
				<div class="row menu-row">
					<div class="col-99 text-center"><a href="/">首页</a></div>
					<div class="col-99 text-center"><a href="At6.php">优惠信息</a></div>
					<div class="col-99 text-center"><a href="javascript:;">彩票游戏</a></div>
					<div class="col-99 text-center"><a href="javascript:;">六合彩</a></div>
					<div class="col-99 text-center"><a href="javascript:;">真人娱乐</a></div>
					<div class="col-99 text-center"><a href="javascript:;">电子娱乐</a></div>
					<div class="col-99 text-center"><a href="javascript:;">沙巴体育</a></div>
					<div class="col-99 text-center"><a href="mobile.php">手机投注</a></div>
					<div class="col-99 text-center"><a href="<?=$this->qq?>">代理加盟</a></div>
				</div>
			</div>
		</div>
	</div>
	<!-- /top會員登入 -->
<script>
function check(form){
	if(form.password1.value==""){
        alert("密码不能为空");
        form.password1.focus();
        return false;
    }
	else{
		var password=$('.upwd').val();
        var username =$('.uname').val();
        $.ajax({
            type: "POST",
            url: "user/logincheck",
            data: {username:username,password:password},
            dataType: "json",
            success: function(data){
                alert(data);
				form.password1.focus();
				return false;
            }       
        });
		
	}
}

</script>	
