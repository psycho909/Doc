<?php if($this->user['uid']){	
	header('location: /');
	exit;
} ?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<link rel="icon" type="image/x-icon" href="images/favicon.ico">
<title>富达彩票-极速彩联盟</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/jh/css/jquery-ui.css">

<link rel="stylesheet" href="/jh/css/stylesheet.css">
<link rel="stylesheet" href="/jh/css/main.css">
<link rel="stylesheet" href="/jh/css/style.css">
<link rel="stylesheet" href="/jh/css/index.css">
<link rel="stylesheet" href="/jh/css/jquery.bxslider.css">
<link rel="stylesheet" href="/jh/css/notice_popup.css">

<script async="" src="/jh/js/analytics.js"></script>
<script src="/jh/js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="/jh/js/jquery-ui.js"></script>
<script type="text/javascript" src="/jh/js/dialog.js"></script>
<script type="text/javascript" src="/jh/js/libs.js"></script>
<script type="text/javascript" src="/jh/js/login.js"></script>

<script type="text/javascript" src="/jh/js/common.js"></script>	

<script type="text/javascript" src="/skin/main/reglogin.js"></script>	
<script type="text/javascript" src="/js/guest.js"></script>	
	
<script type="text/javascript" src="/jh/js/index.js"></script>
<script>
	var stat1 = 25;
	var statprogress1 = 25;  // 25%, percentage
	var stat2 = 120;
	var statprogress2 = 65;  // 65%, e
	var stat3 = 34;
	var affType = 0;
</script>
<script>
//   (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
//   (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
//   m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
//   })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

//   ga('create', 'UA-93117741-1', 'auto');
//   ga('send', 'pageview');

</script>
</head>
<body id="bodyid">
	<!-- top會員登入 -->
	<div class="top">
		<div class="g_w1">
			<!-- 時間 -->
			<div class="time_box">
				<span class="date showTime">2017-05-18 09:21:49</span> 营业时间：白天07:30 - 凌晨04:00 / 全年无休
			</div>
			<!-- /時間 -->

			<!-- 登入FORM -->
			<div class="oper_box">
				<form action="/user/loginon" method="post">
					<div class="login">
					<a href="reg.php"><button type="button" id="btn-register" class="btn btn-red">注册</button></a>
					<div class="l_usn userid form-control">
						<i></i>
						<input type="text" placeholder="会员账号" name="username" class="uname" id="userName1" maxlength="15" tabindex="1">
					</div>
					<div class="l_pwd password form-control">
						<i></i>
						<input type="password" placeholder="密码" name="password" class="upwd" id="password1" maxlength="15" tabindex="2">
						<a href="<?=$this->qq?> "target="_blank" class="btn btn-sm btn-white">忘记?</a>
					</div>
					<input type="submit" class="btn btn-red" value="立即登陆" onclick="return check(form)">
					<a href="javascript:guestLogin();"><span class="btn btn-blue">试玩登录</span></a>
					<?php 
						$sql="select * from ssc_params" ;
					$data = $this->getRows($sql);
						?>
					<a target="_blank" href="<?=$this->qq?>"><div" class="btn btn-yellow"><div style="margin-top:2px; "><img src="/jh/images/mic.png"></div> <div style="margin-left:4px; margin-top: 0;">在线客服</div></div"></a>
					</div>
					<div class="header-links" style="display: none;">
						<ul>
							<li><span class="username"></span></li>
							<!-- <li><span class="tesing"></span></li> -->
							<li class="header-center"><a href="/member/index?page=center/index">个人中心</a></li>
							<li class="header-payment"><a href="/member/index?page=payment/deposit">资金管理</a></li>
							<li><a href="/member/index">进入游戏</a></li>
							<li><a href="/member/logout">退出</a></li>
						</ul>
					
						<div" class="btn btn-yellow floatright"><div style="margin-top:2px; "><a target="_blank" href="<?=$this->qq?>"><img src="jh/images/mic.png"></div> <div style="margin-left:4px; margin-top: 0;">在线客服</div></div"></a>
					</div>
				</form>
			</div>
			<!-- /登入FORM -->

			<div class="g_glear clear"></div>
		</div>
		<div class="g_glear clear"></div>
	</div>
	<!-- /top會員登入 -->
	<!-- top MENU -->
	<div class="topmenu">
		<div class="g_w1">
			<div class="logo"><a href="/"><img src="/jh/images/logo.png" width="244" height="59" alt=""></a>
			</div>
			<div class="menulinks clearfix">
				<a href="/" class="sublinks menuactive">网站首页</a>
				<a href="reg.php" class="sublinks">开户注册</a>
				<a href="At6.php" class="sublinks">优惠活动</a>
				<a href="javascript:;" onclick="ykdl()" class="trade sublinks">存款取款</a>
				<a href="Question.php" class="sublinks">常见问题</a>
				<a href="mobile.php" class="sublinks">手机投注</a>
				<a href="<?=$this->qq?>" target="_blank" class="sublinks">加盟合作</a>
			</div>
		</div>
	</div> 
	<!-- /top MENU-->
<script>
function check(form){
	if(form.password1.value==""){
        alert("密码不能为空");
        form.password1.focus();
        return false;
    }
	else{
		var password=$('.upwd').val();
        var username =$('.uname').val();
        $.ajax({
            type: "POST",
            url: "user/logincheck",
            data: {username:username,password:password},
            dataType: "json",
            success: function(data){
                alert(data);
				form.password1.focus();
				return false;
            }       
        });
		
	}
}

</script>	
