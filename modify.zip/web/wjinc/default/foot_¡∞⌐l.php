<style>
	.ui-widget{
		top:200px !important;
	}
	#ykdl{
		display:none;
	}
</style>

<div class="footernavi2">
	<div class="footercontainer bothborder">
		<div class="col4 borderleft borderright">
			<div class="footercontent">
				<!--<a href="https://1380tt.com" target="_blank"><img src="images/footerlogo1.jpg" width="151" height="80" alt=""></a>-->
			</div>
		</div>
		<div class="col5 borderleft borderright">
			<div class="footercontent">
				<!--<a href="http://sgwin123.com" target="_blank"><img src="images/footerlogo2.jpg" width="168" height="80" alt=""></a>-->
			</div>
		</div>
		<div class="col6 borderleft borderright">
			<div class="footercontent">
				<!--<a href="http://168kai.com/" target="_blank"><img src="images/footerlogo3.jpg" width="160" height="80" alt=""></a>-->
			</div>
		</div>
	</div>
</div> 
<div class="footerindex2">
	©2013-2017  富达娱乐。All Rights Reserved.
</div>
  <!--div class="left_adv">
    <a href="http://www.wangzhi.com/" target="_blank"><img src="/jh/images/MQ2.png"></a>
  </div>

<div class="socialnavi">
	<div class="wechatqr">
		<img src="/dsn/wechat_qr1.png" alt="">
	</div>
	<div class="downloadqr" style="display: none;"><p>下载网址<br>
防劫持发布器</p></div>
<?php 
				 $sql="select * from ssc_params" ;
				 $data = $this->getRows($sql);
					?>
	<div class="qq" onclick="javascript:window.open('<?=$this->qq?>','_blank')"></div>
	<div class="wechat" onclick=""></div>
	<div class="livechat" onclick="javascript:window.open('<?=$this->qq?>','_blank')"></div>
	<div class="download" onclick="javascript:window.open('http://www.fuda8.com/','_blank')"></div>
	<div>
		<a href="javascript:;" onclick="scrolltop();" class="scrolltop" style="display: none;"><img src="/jh/images/support_top.png" width="50" height="50" alt=""></a>
	</div>

</div-->



<div id="ykdl" class="ui-dialog ui-widget ui-widget-content ui-corner-all dialog ui-draggable ui-dialog-buttons" tabindex="-1" role="dialog" aria-labelledby="ui-id-1" style="outline: 0px; z-index: 1002; height: auto; width: 360px; top: 200px; left: 772px;">
	<div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix">
		<span id="ui-id-1" class="ui-dialog-title">消息</span>
		<a href="#" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span class="ui-icon ui-icon-closethick" onclick="close1()">close</span></a>
	</div>
	<div id="dialog" class="ui-dialog-content ui-widget-content" scrolltop="0" scrollleft="0" style="display: block; width: auto; min-height: 81px; height: auto;">
		<div class="field-c">
			<div class="icon"></div>
			<div class="msg">
				<p>您还没有登录！</p>
			</div>
		</div>
	</div>
	<div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix">
		<div class="ui-dialog-buttonset">
			<a href="javascript:guestLogin();"><button class="btn btn-blue">游客登录</button></a>
		</div>
	</div>
</div>

<script src="/jh/js/jquery.bxslider.min.js"></script>
<script src="/jh/js/plugins.js"></script>
<script src="/jh/js/main.js"></script>    
<script>
	function ykdl(){
		$("#ykdl").show();
	}
	function close1(){
		$("#ykdl").hide();
	}
</script>
</body></html>