$(function(){
    // 进入投注页左侧 更多游戏按钮彈出
    $('.more_games').on('click',function(){
        if(!$('.popPanel').hasClass('show')){
            $('.more_games_arrow').text('▲')
        }else{
            $('.more_games_arrow').text('▼')
        }
        console.log($('.popPanel').hasClass('show'))
        $('.popPanel').toggleClass('show')
    })

    // 首页BN滑鼠移動移出效果
    var bnSrc=[];
    $('.bn-col').each(function(){
        bnSrc.push($(this).find('a img').attr('src'))
    })
    $('.bn-col').hover(function(){
        var data=$(this).find('a img').data('img')
        $(this).find('a img').attr('src',data)
    },function(){
        var _index=$(this).index();
        $(this).find('a img').attr('src',bnSrc[_index])
    })

    // 投注页最新注单按钮高度控制
    $('#right_page').on('click','.new-bets-title',function(){
        var mainHeight=$('.main').outerHeight();
        $(this).closest('.sider-col2').find('#lastBets .bets').toggleClass('show');
        if($('#lastBets .bets').hasClass('show')){
            $('.stat_play_list').css({
                'display':'block',
                'max-height':mainHeight-230-50-48+'px'
            })
        }else{
            $('.stat_play_list').css({
                'display':'block',
                'max-height':mainHeight-50-48+'px'
            })
        }
    })

    // 投注頁增加內容
    // 最新注單
    var siderNewBets='<div class="sider-col2 row"><div class="new-bets-title w-100">最新注单</div><div id="lastBets" class="side_left w-100"><ul class="bets" id="user-bet-list"></ul></div></div>';
    // 遊戲BN
    var bnRow='<div class="row"><div class="col-12"><img class="img-fluid game-banner" src="../../skin/images/lottery.jpg" alt=""></div></div>';
    // 快捷/一般/開獎號區
    var resultBalls='<div class="d-flex bg-white mb-2 justify-content-between"><div class="h-100 d-flex justify-content-center align-items-center p-3"><div class="btn-wrap"><button class="btn btn-toggle btn-quickly toggle">快捷</button><button class="btn btn-toggle btn-normal">一般</button></div></div><div class="d-flex flex-column p-3"><div class="mb-1"><span id="header_game_name" class="header_game_name mr-3"></span><span class="cur_turn_num mr-1" id="cur_turn_num"></span>期开奖</div><div class="menu1"><a target="_blank" class="result_balls"></a></div></div></div>';
    // 增加BN
    $('.main .content .sub-wrap .cont-main').prepend(bnRow)
    // 增加快捷/一般/開獎號區
    $('.main .content .sub-wrap .cont-main .game-type-row').after(resultBalls)
    // 增加最新注單
    $('#right_page').prepend(siderNewBets)

    // 切換快捷/一般
    $('.main').on('click','.btn-toggle',function(){
        $(this).addClass('toggle').siblings().removeClass('toggle')
    })

    // 音樂開關
    var soundSwitch='<div class="mr-auto sound-switch open_sound" onclick="SoundManage.voiceSwitch()" id="countdown_sound" title="点击关闭提醒声音"></div'
    $('#homeCateMenus .cate_menu').append(soundSwitch)
})